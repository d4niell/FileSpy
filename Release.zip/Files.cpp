#include <iostream>
#include <conio.h>
#include <fstream>
#include <sstream>
#include <windows.h>
#include <filesystem>
#include <vector>
#include <cstdlib>
#include <string>
#include "dirent.h";
#ifdef _UNICODE
typedef std::wstring tstring;
#else
typedef std::string tstring;
#endif
//namespace file = std::filesystem;
int FileSeparationLine = 0;
std::string filename;
std::string option1 = ""; //reason i made these is because when you stop the scan it's more easier to use the "available options" as a base and just change these strings
std::string option2 = "";
std::string option3 = "";
int SetPermission = false;
int rand();
int file_size;
struct dirent* SilentIsFileDirectory;

int SilentFile_size;
int main();
int FileUID;
int SilentFileUID;
int SilentFileSeparationLine = 0;
struct dirent* IsFileDirectory;
char key = _getch();
void SetColor(int color);
void Position(int x, int y);
bool CrashError() {

	system("title handling refresh request...");
	main();
	return 0;
}
using namespace std;
void GetProjectPathDirectory() {

}
void OnCreateNewFile() {
	system("title Creating New File");
	Position(80, 40);
	std::cout << "::"; std::cin >> filename;
	std::ofstream file;
	file.open(filename);
	if (file.is_open()) {
		Position(80,42);
		SetColor(2);
		std::cout << filename; SetColor(3); std::cout << " created";
	}
	else {
		Position(80, 42);
		std::cout << "error while creating a file (maybe it exists)";
	
	}



}
bool OnSendShutdown()
{





	return 1;
}
void SetColor(int color) { //added way after i spammed those manual color changers
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);

}
void SilentCheckDir();
void Position(int x, int y) {
	COORD c;
	c.X = x;
	c.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);

}
void OnStartScanning() {
	int sec = 0, hr = 0, min = 0;
	int OnTimeElapsed = 0;
	while (true) {
		sec++;
		if (sec == 60) {
			min++;
			if (min == 60) {
				hr++;
			}
		}
		SilentCheckDir();
		SilentFileSeparationLine == 0;
		OnTimeElapsed++;
		Position(1, 51);
		system("title Scanning Started!");
		std::cout << "Scanning Started. ";
		Position(80, 15);
		std::cout << "Scan Info:";
		Position(80, 16);
		std::cout << "elapsed time: " << hr << " |H| " << min << " |M| " << sec << " |S| ";

		Sleep(2000);

	}

}
void DisplayMenu() {
	int Set[] = { 7,7,7 };
	int counter = 2;
	for (int i = 0;;)
	{
		key = _getch();
		Position(80, 8);
		SetColor(Set[0]);
		option1 = "Start Scan";
		std::cout << option1;

		Position(80, 9);
		SetColor(Set[1]);
		option2 = "Create File";
		std::cout << option2;

		Position(80, 10);
		SetColor(Set[2]);
		option3 = "info";
		std::cout << option3;


		if (key == 72 && counter >= 2 && counter <= 3) { //uparrow
			counter--;
		}
		if (key == 80 && counter >= 1 && counter <= 2) { //downkey
			counter++;
		}

		if (key == '\r') //"enter" key aka return
		{
			if (counter == 1)
			{
				OnStartScanning();
				option1 = "";
				option2 = "";
				option3 = "";
			}
			if (counter == 2)
			{
				OnCreateNewFile();
				option1 = "";
				option2 = "";
				option3 = "";
			
			}
			if (counter == 3)
			{

			}

		}


		Set[0] = 7;
		Set[1] = 7;
		Set[2] = 7;
		if (counter == 1)
		{
			Set[0] = 12;
		}
		if (counter == 2)
		{
			Set[1] = 12;
		}
		if (counter == 3)
		{
			Set[2] = 12;
		}
	}
}
int oncheckamount = 0;
void SilentCheckDir() {
	system("title Checking Files If Exist");
	std::string SilentIsDirectoryPath;
	DIR* dir;


	
	int IsFolder_dir = false;




	dir = opendir(".");
	std::string ReasonDetect = "false detect";

	if (dir != NULL) {
		
		system("title Getting Directory Path");
	
		system("title Checking Files");
		if (key = 80) {
			SetPermission = true;
			ReasonDetect = "key interrupt";
		}
		while ((SilentIsFileDirectory = readdir(dir)) != NULL) {
			SilentFileUID = file_size + SilentIsFileDirectory->d_namlen;
			SilentFileSeparationLine++;
		
			std::ifstream dfile(SilentIsFileDirectory->d_name, ios::binary);
			dfile.seekg(0, ios::end);
			SilentFile_size = dfile.tellg();
			dfile.close();
			/*if (SilentFileSeparationLine < FileSeparationLine) {
				SetPermission = true;
				ReasonDetect = "File Delete";
		}*/
			if (SilentFileSeparationLine > FileSeparationLine) {
				if (SilentIsFileDirectory->d_name == filename) {
					
				}
				Position(80, 19);
				SetPermission = true;
				ReasonDetect = "New File";
			}
			if (FileUID == SilentFileUID) {
				Position(80, 18);
				if (file_size != SilentFile_size) {
					SetPermission = true;
					Position(80, 19);
					ReasonDetect = "Filesize";
				}


			}
			
				
				
		}
			
			if (MAX_PATH && SetPermission == true) {
				


				system("title SCAN STOPPED!");
			scanresult:

				Position(80, 15);
				std::cout << "->Scanning Stopped! Scanning Results:";
				Position(80, 16);
				std::cout << "->Total Scan Time: ";
				Position(80, 18);
				std::cout << "->Stopped Scanning Due Detection!";
				Position(80, 19);
				std::cout << "->Reason Stopped:" << ReasonDetect;

				int Set[] = { 7,7,7 };
				int counter = 2;
				for (int i = 0;;)
				{
					option1 = "Show info of detected file";
					option2 = "continue scan";
					option3 = "Quit";
					Position(80, 8);
					SetColor(Set[0]);
					std::cout << option1;

					Position(80, 9);
					SetColor(Set[1]);
					std::cout << option2;

					Position(80, 10);
					SetColor(Set[2]);
					std::cout << option3;
					key = _getch();

					if (key == 72 && counter >= 2 && counter <= 3) { //uparrow
						counter--;
					}
					if (key == 80 && counter >= 1 && counter <= 2) { //downkey
						counter++;
					}

					if (key == '\r') //"enter" key aka return
					{
						if (counter == 1)
						{
							if (SilentIsFileDirectory->d_type == 16384) {
								IsFolder_dir == true;
							}
							system("cls");
							std::cout << "Detected File:"; SetConsoleTextAttribute((HANDLE)GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN); std::cout << SilentIsFileDirectory->d_name; SetConsoleTextAttribute((HANDLE)GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY); std::cout << "\n->Reason Detected: " << ReasonDetect << "\nFileType->" << SilentIsFileDirectory->d_type << "\nIs Folder/Directory  {" << IsFolder_dir << "}" << "\n\nAdvanced Info:\n->" << SilentIsFileDirectory->d_reclen << "\n->" << SilentIsFileDirectory->d_namlen << std::endl;
							std::ifstream dfile(SilentIsFileDirectory->d_name, ios::binary);
							dfile.seekg(0, ios::end);
							int file_size = dfile.tellg();
							std::cout << "FileSize:" << file_size << std::endl;
							system("pause");
							main();

						}
						if (counter == 2)
						{
							OnStartScanning();
						}
						if (counter == 3)
						{

						}

					}


					Set[0] = 7;
					Set[1] = 7;
					Set[2] = 7;
					if (counter == 1)
					{
						Set[0] = 12;
					}
					if (counter == 2)
					{
						Set[1] = 12;
					}
					if (counter == 3)
					{
						Set[2] = 12;
					}
				}


			}

		}

		Sleep(1);
		SilentFileSeparationLine = 0;
}
	
	








bool OnGetFilesForAnalyze() {
	std::string OnMakeChoice;
	std::string IsDirectoryPath;
	DIR* dir;

	dir = opendir(".");
	if (dir != NULL) {

		while ((IsFileDirectory = readdir(dir)) != NULL) {
			std::ifstream dfile(IsFileDirectory->d_name, ios::binary);
			dfile.seekg(0, ios::end);
			file_size = dfile.tellg();
			dfile.close();
			FileSeparationLine++;
			FileUID = file_size + IsFileDirectory->d_namlen;
			std::cout << "\n""******************************************";


		SetRefresh: {
			SetConsoleTextAttribute((HANDLE)GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY);

			std::cout << "\nFILENAME:["; SetConsoleTextAttribute((HANDLE)GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN); std::cout << IsFileDirectory->d_name; SetConsoleTextAttribute((HANDLE)GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY); std::cout << "] Size:" << file_size << " KiloBytes/KB";
		
			if (IsFileDirectory->d_type == 16384) {
				SetConsoleTextAttribute((HANDLE)GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN);
				printf("    <-folder/directory");
				SetConsoleTextAttribute((HANDLE)GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY);
			}

			if (IsFileDirectory->d_name == NULL) {
				std::cout << "UNKNOWN FILE FOUND! " << "FileNumber==" << FileSeparationLine << "Presumptive Non-Prepared FileType:" << IsFileDirectory->d_type;
				std::cout << "if you think this was an mistake please contact niazy#8876\n";
			}
			}

		
		}
		std::cout << "\nscan (success) files found:" << FileSeparationLine;
		Position(80, 6);
		std::cout << "available actions:";
		Position(80, 7); std::cout << "{"; Position(80, 11); std::cout << "}";
		DisplayMenu();


		std::string cmd;
		if (OnMakeChoice == "rfresh" || "refresh" || "r") {
			if (OnMakeChoice == OnMakeChoice) {
				std::cout << ":"; std::cin >> cmd;
				std::ofstream OnCreateNewApplication;
				OnCreateNewApplication.open(cmd);
				OnCreateNewApplication.close();
				SetConsoleTextAttribute((HANDLE)GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY);
				system("cls");
				main();
			}
			if (OnMakeChoice == "scanl") { //this fixes an issue between the "scanl" if statement, if you remove this you cant type scanl, because it will just refresh


			}









		}
	}
}

int checked = 0;
int  main() {
	system("mode 120");

	SetConsoleTextAttribute((HANDLE)GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY);
	SetConsoleTextAttribute((HANDLE)GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN);
	system("title build 19/04/2021");
	OnGetFilesForAnalyze();
	GetProjectPathDirectory();






	return 0;
}